/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.iglnierod.gamearchive.model.api.igdb;

/**
 *
 * @author iglnierod
 */
public enum ImageType {
    COVER_SMALL, SCREESHOT_MED, COVER_BIG, LOGO_MED, SCREENSHOT_BIG, SCREENSHOT_HUGE,
    THUMB, MICRO, _720P, _1080P
}
